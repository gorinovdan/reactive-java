package rj.lab1.model;

public enum ReceiptStatus {
    PAID, PENDING, DELIVERED, FAILED
}
