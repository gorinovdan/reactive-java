package lab3.model;

public enum ReceiptStatus {
    PAID, PENDING, DELIVERED, FAILED
}
